import React from 'react';
import { Leaf } from 'lucide-react';
import Hero from './components/Hero';
import Services from './components/Services';
import CarbonCalculator from './components/Calculator';
import ConsultationForm from './components/ConsultationForm';
import WhyChooseUs from './components/WhyChooseUs';
import Products from './components/Products';
import AccessibilitySettings from './components/AccessibilitySettings';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-green-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Leaf className="h-8 w-8" />
              <span className="ml-2 text-xl font-bold">Rolsa Technologies</span>
            </div>
            <div className="hidden md:block">
              <div className="flex items-center space-x-4">
                <a href="#services" className="hover:text-green-200">Services</a>
                <a href="#products" className="hover:text-green-200">Products</a>
                <a href="#calculator" className="hover:text-green-200">Carbon Calculator</a>
                <a href="#consultation" className="hover:text-green-200">Book Consultation</a>
                <button className="bg-white text-green-600 px-4 py-2 rounded-md font-medium hover:bg-green-50">
                  Sign In
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main>
        <Hero />
        <Services />
        <Products />
        <WhyChooseUs />
        <CarbonCalculator />
        <ConsultationForm />
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
              <p>Email: contact@rolsa.tech</p>
              <p>Phone: (555) 123-4567</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><a href="#services" className="hover:text-green-400">Our Services</a></li>
                <li><a href="#products" className="hover:text-green-400">Our Products</a></li>
                <li><a href="#calculator" className="hover:text-green-400">Carbon Calculator</a></li>
                <li><a href="#consultation" className="hover:text-green-400">Book a Consultation</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="hover:text-green-400">Twitter</a>
                <a href="#" className="hover:text-green-400">LinkedIn</a>
                <a href="#" className="hover:text-green-400">Facebook</a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <AccessibilitySettings />
    </div>
  );
}

export default App;