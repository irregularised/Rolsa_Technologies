import React from 'react';
import { Sun, Car, Home } from 'lucide-react';

export default function Services() {
  const services = [
    {
      title: 'Solar Panel Solutions',
      description: 'High-efficiency solar panels with professional installation and maintenance services.',
      icon: Sun,
      image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-1.2.1&auto=format&fit=crop&w=1352&q=80'
    },
    {
      title: 'EV Charging Stations',
      description: 'Smart charging solutions for your electric vehicle, with flexible installation options.',
      icon: Car,
      image: 'https://images.unsplash.com/photo-1593941707882-a5bba14938c7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1352&q=80'
    },
    {
      title: 'Smart Home Energy',
      description: 'Intelligent energy management systems to optimize your home power consumption.',
      icon: Home,
      image: 'https://images.unsplash.com/photo-1558002038-1055907df827?ixlib=rb-1.2.1&auto=format&fit=crop&w=1352&q=80'
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Our Services
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Comprehensive green energy solutions for your home and business
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-16 lg:grid-cols-3">
          {services.map((service) => (
            <div key={service.title} className="flex flex-col">
              <div className="flex-1">
                <div className="relative pb-[56.25%]">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="absolute h-full w-full object-cover rounded-lg"
                  />
                </div>
                <div className="mt-6">
                  <div className="flex items-center">
                    <service.icon className="h-6 w-6 text-green-600" />
                    <h3 className="ml-3 text-xl font-medium text-gray-900">{service.title}</h3>
                  </div>
                  <p className="mt-3 text-base text-gray-500">{service.description}</p>
                </div>
              </div>
              <div className="mt-6">
                <a
                  href="#consultation"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                >
                  Learn More
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}