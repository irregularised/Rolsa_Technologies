import React from 'react';
import { Shield, Clock, Award, Users } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    {
      icon: Shield,
      title: 'Certified Experts',
      description: 'Our team consists of certified professionals with years of experience in green technology installation and maintenance.'
    },
    {
      icon: Clock,
      title: '24/7 Support',
      description: 'Round-the-clock customer support to ensure your green energy systems are always running optimally.'
    },
    {
      icon: Award,
      title: 'Quality Guarantee',
      description: 'We use only the highest quality products and provide comprehensive warranties on all installations.'
    },
    {
      icon: Users,
      title: 'Customer Satisfaction',
      description: '98% customer satisfaction rate with over 1,000 successful installations across the region.'
    }
  ];

  return (
    <section id="why-choose-us" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Why Choose Rolsa Technologies
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Leading the way in sustainable energy solutions with expertise and dedication
          </p>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {reasons.map((reason) => (
            <div key={reason.title} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-500 text-white mx-auto">
                <reason.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900 text-center">
                {reason.title}
              </h3>
              <p className="mt-2 text-base text-gray-500 text-center">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}