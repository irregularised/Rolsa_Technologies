import React from 'react';
import { Sun, Battery, Cpu } from 'lucide-react';

export default function Products() {
  const products = [
    {
      category: 'Solar Panels',
      items: [
        {
          name: 'Premium Solar Panel Kit',
          description: 'High-efficiency 400W panels with 25-year warranty',
          price: '$899',
          features: ['400W output', 'Monocrystalline', 'Anti-reflective coating']
        },
        {
          name: 'Solar Panel + Battery Bundle',
          description: 'Complete home solar solution with storage',
          price: '$2,499',
          features: ['600W panels', '10kWh battery', 'Smart monitoring']
        }
      ]
    },
    {
      category: 'EV Charging',
      items: [
        {
          name: 'Home EV Charger',
          description: 'Level 2 charging station for residential use',
          price: '$599',
          features: ['40A output', 'WiFi enabled', 'Schedule charging']
        },
        {
          name: 'Commercial Charging Station',
          description: 'Dual-port commercial grade charger',
          price: '$1,999',
          features: ['Dual 80A ports', 'Payment system', 'Load balancing']
        }
      ]
    },
    {
      category: 'Smart Home',
      items: [
        {
          name: 'Energy Management Hub',
          description: 'Central control for all your energy needs',
          price: '$399',
          features: ['Real-time monitoring', 'AI optimization', 'Mobile app']
        },
        {
          name: 'Smart Thermostat Pro',
          description: 'Advanced temperature control system',
          price: '$199',
          features: ['Learning algorithm', 'Zone control', 'Energy reports']
        }
      ]
    }
  ];

  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Our Products
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Cutting-edge green technology solutions for every need
          </p>
        </div>

        <div className="mt-16 space-y-16">
          {products.map((category) => (
            <div key={category.category} className="space-y-8">
              <h3 className="text-2xl font-bold text-gray-900">{category.category}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {category.items.map((product) => (
                  <div key={product.name} className="bg-gray-50 rounded-lg p-6 shadow-md">
                    <h4 className="text-xl font-semibold text-gray-900">{product.name}</h4>
                    <p className="mt-2 text-gray-600">{product.description}</p>
                    <p className="mt-4 text-2xl font-bold text-green-600">{product.price}</p>
                    <ul className="mt-4 space-y-2">
                      {product.features.map((feature) => (
                        <li key={feature} className="flex items-center text-gray-600">
                          <span className="h-1.5 w-1.5 bg-green-600 rounded-full mr-2"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <button className="mt-6 w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors">
                      Learn More
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}