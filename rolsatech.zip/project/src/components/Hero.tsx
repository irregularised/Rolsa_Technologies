import React from 'react';
import { Sun } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-green-600">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover"
          src="https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-1.2.1&auto=format&fit=crop&w=2850&q=80"
          alt="Solar panels on a modern house"
        />
        <div className="absolute inset-0 bg-green-600 mix-blend-multiply" />
      </div>
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          Power Your Future with Green Technology
        </h1>
        <p className="mt-6 text-xl text-white max-w-3xl">
          Transform your home into a sustainable powerhouse with our cutting-edge solar solutions,
          EV charging stations, and smart energy management systems.
        </p>
        <div className="mt-10 flex space-x-4">
          <a
            href="#consultation"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-green-600 bg-white hover:bg-green-50"
          >
            Book a Consultation
          </a>
          <a
            href="#calculator"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-green-500 hover:bg-green-400"
          >
            Calculate Your Impact
          </a>
        </div>
      </div>
    </div>
  );
}