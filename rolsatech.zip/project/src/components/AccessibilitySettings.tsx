import React, { useState } from 'react';
import { Settings } from 'lucide-react';

export default function AccessibilitySettings() {
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState({
    fontSize: 'normal',
    contrast: 'normal',
    reducedMotion: false,
    dyslexicFont: false
  });

  const applySettings = () => {
    document.documentElement.className = [
      settings.fontSize === 'large' ? 'text-lg' : '',
      settings.fontSize === 'larger' ? 'text-xl' : '',
      settings.contrast === 'high' ? 'high-contrast' : '',
      settings.reducedMotion ? 'reduce-motion' : '',
      settings.dyslexicFont ? 'dyslexic-font' : ''
    ].filter(Boolean).join(' ');
  };

  const handleSettingChange = (setting: string, value: string | boolean) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
  };

  React.useEffect(() => {
    applySettings();
  }, [settings]);

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition-colors"
        aria-label="Accessibility Settings"
      >
        <Settings className="h-6 w-6" />
      </button>

      {isOpen && (
        <div className="absolute bottom-16 right-0 w-72 bg-white rounded-lg shadow-xl p-4">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Accessibility Settings</h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Text Size
              </label>
              <select
                value={settings.fontSize}
                onChange={(e) => handleSettingChange('fontSize', e.target.value)}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              >
                <option value="normal">Normal</option>
                <option value="large">Large</option>
                <option value="larger">Larger</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contrast
              </label>
              <select
                value={settings.contrast}
                onChange={(e) => handleSettingChange('contrast', e.target.value)}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
              >
                <option value="normal">Normal</option>
                <option value="high">High Contrast</option>
              </select>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="reducedMotion"
                checked={settings.reducedMotion}
                onChange={(e) => handleSettingChange('reducedMotion', e.target.checked)}
                className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
              />
              <label htmlFor="reducedMotion" className="ml-2 block text-sm text-gray-700">
                Reduce Motion
              </label>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="dyslexicFont"
                checked={settings.dyslexicFont}
                onChange={(e) => handleSettingChange('dyslexicFont', e.target.checked)}
                className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
              />
              <label htmlFor="dyslexicFont" className="ml-2 block text-sm text-gray-700">
                Dyslexic-friendly Font
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}